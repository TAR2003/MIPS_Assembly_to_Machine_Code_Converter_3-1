#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include "2005090_SymbolInfo.h"
using namespace std;

class ScopeTable
{
private:
    int total_buckets;
    int id;
    SymbolInfo **arr;
    ScopeTable *parentScope;
    int p;

public:
    ScopeTable(int n, ScopeTable *sc, int parentid)
    {

        total_buckets = n;
        arr = new SymbolInfo *[total_buckets];
        parentScope = sc;
        for (int i = 0; i < total_buckets; i++)
        {
            arr[i] = NULL;
        }

        id = parentid;
    }
    ~ScopeTable()
    {
        // cout << "deleting " << id << endl;
        for (int i = 0; i < total_buckets; i++)
        {
            delete arr[i];
        }
        delete[] arr;
        // cout << "\tScopeTable# " << id << " deleted\n";
        if (parentScope != NULL)
            delete parentScope;
    }

    unsigned long long sdbmhash(string str)
    {
        unsigned long long hash = 0;
        int c;

        for (int i = 0; i < str.size(); i++)
        {
            c = (int)(str[i]);
            // cout << c << endl;
            hash = c + ((hash << 6)) + ((hash << 16)) - (hash);
            // hash = hash % total_buckets;
        }
        return hash % total_buckets;
    }
    int getId() { return id; }
    ScopeTable *getParent() { return parentScope; }
    void setParent(ScopeTable *sc)
    {
        parentScope = sc;
    }

    string print()
    {
        string str = "\tScopeTable# " + to_string(id) + '\n';
        // cout << "id no " << id << endl;
        // cout << str << endl;
        for (int i = 0; i < total_buckets; i++)
        {
            int pos = i + 1;
            if (arr[i] == NULL)
                continue;
            str += '\t';
            str += to_string(i + 1);
            str += "--> ";
            if (arr[i] != NULL)
            {
                str += arr[i]->print();
            }
            str += '\n';
        }
        // cout << str << " her eis the " << endl;
        return str;
    }
    SymbolInfo *find(string name)
    {
        int i = sdbmhash(name);
        SymbolInfo *sc = arr[i];
        if (arr[i] == NULL)
            return NULL;
        while (sc)
        {
            if (sc->getName().compare(name) == 0)
            {
                return sc;
            }
            else
            {
                sc = sc->getNextSymbolInfo();
            }
        }
        return NULL;
    }

    bool insert(string name, string type)
    {
        // to make sure no duplicates

        if (find(name) != NULL)
        {
            // cout << "\t" << name << " already exists in the current ScopeTable\n";

            return false;
        }

        // making sure

        int pos = sdbmhash(name);
        int x = pos + 1, y = 1;
        SymbolInfo *si = new SymbolInfo(name, type);
        SymbolInfo *sc = arr[pos];
        if (sc)
        {
            y = 2;
            while (sc->getNextSymbolInfo())
            {
                sc = sc->getNextSymbolInfo();
                y++;
            }

            sc->setNextSymbolInfo(si);
        }
        else
        {
            arr[pos] = si;
        }
        // si->setSid(id);
        // si->setX(x);
        // si->setY(y);
        // cout << "\tInserted  at position <" << x << ", " << y << "> of ScopeTable# " << id << endl;
        return true;
    }
    bool insert(string name, string type, string rtype)
    {
        // to make sure no duplicates

        if (find(name) != NULL)
        {
            // cout << "\t" << name << " already exists in the current ScopeTable\n";

            return false;
        }

        // making sure

        int pos = sdbmhash(name);
        int x = pos + 1, y = 1;
        SymbolInfo *si = new SymbolInfo(name, type, rtype);
        SymbolInfo *sc = arr[pos];
        if (sc)
        {
            y = 2;
            while (sc->getNextSymbolInfo())
            {
                sc = sc->getNextSymbolInfo();
                y++;
            }

            sc->setNextSymbolInfo(si);
        }
        else
        {
            arr[pos] = si;
        }
        // si->setSid(id);
        // si->setX(x);
        // si->setY(y);
        // cout << "\tInserted  at position <" << x << ", " << y << "> of ScopeTable# " << id << endl;
        return true;
    }
    SymbolInfo *lookUp(string name)
    {

        int i = sdbmhash(name);
        int j = 1;
        // cout << i << "has h " << endl;
        SymbolInfo *sc = arr[i];
        // cout << " in ;looking up " << endl;
        if (arr[i] == NULL)
            return NULL;
        while (sc)
        {
            if (sc->getName().compare(name) == 0)
            {
                // cout << sc->getName() << " and " << name << " are same\n";
                // cout << "\t'" << name << "' found at position <" << (i + 1) << ", " << j << "> of ScopeTable# " << id << endl;
                return sc;
            }

            else
            {
                sc = sc->getNextSymbolInfo();
                j++;
            }
        }

        return NULL;
    }
    bool deleteSymbolInfo(string name)
    {
        int i = sdbmhash(name);
        int j = 1;
        SymbolInfo *sc;
        sc = NULL;

        SymbolInfo *temp = arr[i];
        if (arr[i] == NULL)
        {
            temp = NULL;
            sc = NULL;
        }
        else if (arr[i]->getName().compare(name) == 0)
        {
            sc = arr[i];
            arr[i] = arr[i]->getNextSymbolInfo();
        }
        else
        {
            j = 2;
            while (temp->getNextSymbolInfo())
            {
                if (temp->getNextSymbolInfo()->getName().compare(name) == 0)
                {
                    sc = temp->getNextSymbolInfo();
                    temp->setNextSymbolInfo(sc->getNextSymbolInfo());
                    break;
                }
                else
                {
                    j++;
                    temp = temp->getNextSymbolInfo();
                }
            }
        }
        if (sc == NULL)
        {
            cout
                << "\tNot found in the current ScopeTable# "
                << id
                << endl;
            return false;
        }
        sc->setNextSymbolInfo(NULL);
        delete sc;
        cout << "\tDeleted '" << name << "' from position <" << (i + 1) << ", " << j << "> of ScopeTable# " << id << endl;
        return true;
    }
    void increase() { p++; }
};
