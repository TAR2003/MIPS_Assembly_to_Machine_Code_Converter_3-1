clear #
yacc -d -y 2005090.y #
g++ -w -c -o y.o y.tab.c #
flex 2005090.l #
g++ -w -c -o l.o lex.yy.c #
g++ y.o l.o -lfl -o 2005090 # #
./2005090 input.asm #
