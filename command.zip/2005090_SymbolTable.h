#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include "2005090_ScopeTable.h"
using namespace std;

class SymbolTable
{
private:
    int total_buckets;
    ScopeTable *currentScopeTable;
    int scopetables;

public:
    ScopeTable *nextPossibleSymboltable;
    SymbolTable(int n)
    {
        total_buckets = n;
        scopetables = 1;
        ScopeTable *sc = new ScopeTable(total_buckets, NULL, 1);
        currentScopeTable = sc;
        nextPossibleSymboltable = NULL;
    }
    ~SymbolTable()
    {
        delete nextPossibleSymboltable;
        delete currentScopeTable;
    }
    bool addPossible(string name, string type)
    {
        // cout << "name " << name << endl;
        if (nextPossibleSymboltable)
            return nextPossibleSymboltable->insert(name, type);
        else
        {
            nextPossibleSymboltable = new ScopeTable(total_buckets, currentScopeTable, scopetables + 1);
            return nextPossibleSymboltable->insert(name, type);
        }
    }
    void enterScope()
    {
        // cout << "Emtred a new table" << endl;
        scopetables++;
        ScopeTable *sc;
        if (nextPossibleSymboltable)
            sc = nextPossibleSymboltable;
        else
        {
            sc = new ScopeTable(total_buckets, currentScopeTable, scopetables);
        }
        nextPossibleSymboltable = NULL;

        currentScopeTable = sc;
    }
    void exitScope()
    {
        // cout << this->printAll();
        nextPossibleSymboltable = NULL;

        if (currentScopeTable->getParent() == NULL)
        {
            // cout << "\tScopeTable# 1 cannot be deleted" << endl;
            return;
        }
        ScopeTable *sc = currentScopeTable;
        currentScopeTable = currentScopeTable->getParent();
        sc->setParent(NULL);
        delete sc;
    }
    bool insert(string name, string type)
    {
        return (currentScopeTable->insert(name, type));
    }
    bool insert(string name, string type, string rtype)
    {
        return (currentScopeTable->insert(name, type, rtype));
    }
    bool insert(char *n, char *t)
    {
        string name(n);
        string type(t);
        return (currentScopeTable->insert(name, type));
    }
    bool remove(string name)
    {
        // cout << "deleting scopetable " << currentScopeTable->getId() << " " << name << endl;
        return currentScopeTable->deleteSymbolInfo(name);
    }
    SymbolInfo *lookUpCurrent(string name)
    {
        return currentScopeTable->lookUp(name);
    }
    SymbolInfo *lookUp(string name)
    {
        SymbolInfo *sc = NULL;
        ScopeTable *temp = currentScopeTable;
        while (temp)
        {

            sc = temp->lookUp(name);
            if (sc != NULL)
                break;
            else
            {

                if (temp->getParent() == NULL)
                    break;
                else
                    temp = temp->getParent();
            }
        }

        return sc;
    }
    string printCurrent()
    {
        return currentScopeTable->print();
    }
    string printAll()
    {
        string str = currentScopeTable->print();
        ScopeTable *temp;
        temp = currentScopeTable->getParent();
        while (temp)
        {
            str += temp->print();
            temp = temp->getParent();
        }
        return str;
    }
    char *printAllinChar()
    {
        string str = currentScopeTable->print();
        ScopeTable *temp;
        temp = currentScopeTable->getParent();
        while (temp)
        {
            str += temp->print();
            temp = temp->getParent();
        }
        char *c = new char[str.size() + 1];
        for (int i = 0; i < str.size() + 1; i++)
        {
            c[i] = str[i];
        }
        return c;
    }
};
